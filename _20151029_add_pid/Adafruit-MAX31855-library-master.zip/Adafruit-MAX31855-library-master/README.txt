This is the Adafruit MAX31885 Arduino Library 

Tested and works great with the Adafruit Thermocouple Breakout w/MAX31885K
    ------> http://www.adafruit.com/products/269

These modules use SPI to communicate, 3 pins are required to  
interface

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada  for Adafruit Industries.  
BSD license, check license.txt for more information
All text above must be included in any redistribution

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder Adafruit_MAX31885. Check that the Adafruit_MAX31885 folder contains Adafruit_MAX31885.cpp and Adafruit_MAX31885.h

Place the Adafruit_MAX31885 library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.